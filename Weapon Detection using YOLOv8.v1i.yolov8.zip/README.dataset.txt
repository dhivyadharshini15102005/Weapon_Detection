# Weapon Detection using YOLOv8 > 2025-04-16 2:14pm
https://universe.roboflow.com/dhivya-1yjlf/weapon-detection-using-yolov8-o0jah-q02qz

Provided by a Roboflow user
License: CC BY 4.0

